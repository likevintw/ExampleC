// Printf A2
#include <stdio.h>
#include "header.h"
int Data(100);
// Input and Output
void A()
{
	
	printf("Data: %d\n", Data);
}
