// Printf A2
#include <stdio.h>
#include "header.h"
void B()
{
	printf("Data: %d\n", Data);
}

