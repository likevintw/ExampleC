// Printf A2
#include "header.h"

int main()
{
	A();
	B();
	return 0;
}

