// Printf A2
#include <stdio.h>

extern int Data;

void A();
void B();

